-module(player).
-export([start/4, player_engine/4]).

start(Name, Credits, MasterProcess,Players) ->
    register(Name, self()),
    player_engine(Name, Credits, MasterProcess,Players).

player_engine(Name, Credits, MasterProcess,Players) ->
    receive
        {play_game, Opponent} ->
            if Credits =< 0 ->
                MasterProcess ! {player_disqualified, Name};
            true ->
                Opponent ! {invitation, self(), Name},
                player_engine(Name, Credits, MasterProcess,Players)
            end;

        {invitation, OpponentPid, OpponentName} ->
            if Credits =< 0 ->
                OpponentPid ! {game_rejected, self(), Name};
            true ->
                MasterProcess ! {game_request, self(), Name, OpponentPid, OpponentName}
            end,
            player_engine(Name, Credits, MasterProcess,Players);

        {game_id, GameId} ->
            Move = random_move(),
            
            MasterProcess ! {match_move, GameId, self(), Move},
            player_engine(Name, Credits, MasterProcess,Players);

        {game_result, GameId, Result,Player1Name,Move1,Player2Name,Move2,LostPlayerName,MovesRecord} ->
            NewCredits = if Result =:= lost -> Credits - 1; true -> Credits end,

            Games = lists:filter(fun({GID, {_,_},{_,_}}) -> GID == GameId end, MovesRecord),
            GameCount = length(Games),
            if GameCount > 1 ->
                GamesString = lists:foldl(
                    fun({GID, {P1, P1Move}, {P2, P2Move}}, Acc) ->
                        {_, P1Name} = lookup_name_by_process_id(P1),
                        {_, P2Name} = lookup_name_by_process_id(P2),
                        GameString = io_lib:format("~p:~p -> ~p:~p, ", [P2Name, P2Move, P1Name, P1Move]),
                        [GameString | Acc]
                    end,
                    [],
                    Games
                ),
                FormattedEndString = lists:flatten(GamesString),
                io:format("$ (~p) ~s = ~p ~p [~p Credits Left]~n", [GameId, FormattedEndString,LostPlayerName,Result,Credits]);
            true ->
                io:format("$ (~p) ~p:~p -> ~p:~p =~p ~p [~p Credits Left]~n", [GameId,Player2Name,Move2,Player1Name,Move1,LostPlayerName,Result,NewCredits])
            end,
            if(NewCredits =< 0) ->
                io:format("- (~p) Player ~p has no credits left and so disqualified.~n", [GameId, Name]);
            true ->
                ok
            end,
            MasterProcess ! {update_players, LostPlayerName, NewCredits},
            player_engine(Name, NewCredits, MasterProcess,Players);
        

        {game_tied, GameId} ->
            Move = random_move(),
            MasterProcess ! {match_move, GameId, self(), Move},
            player_engine(Name, Credits, MasterProcess,Players)

    after 10 + random:uniform(101)->
        OtherPlayers = lists:filter(fun(P) -> P =/= Name end,Players),
        if OtherPlayers =/= [] ->
            RandomOpponent = lists:nth(rand:uniform(length(OtherPlayers)), OtherPlayers),
            self() ! {play_game, RandomOpponent},
            player_engine(Name, Credits, MasterProcess,Players);

        true ->
            timer:sleep(101)
        end,
        player_engine(Name, Credits, MasterProcess,Players)
    end.

random_move() ->
    Moves = [rock, paper, scissors],
    lists:nth(rand:uniform(3), Moves).

lookup_name_by_process_id(Pid) ->
    NameList = erlang:registered(),
    lists:foldl(
        fun(Name, Acc) ->
            case whereis(Name) of
                Pid ->
                    {ok, Name};
                _ ->
                    Acc
            end
        end,
        {error, not_found},
        NameList
    ).
